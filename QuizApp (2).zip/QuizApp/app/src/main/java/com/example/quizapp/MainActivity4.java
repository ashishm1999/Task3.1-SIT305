package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity4 extends AppCompatActivity {

    TextView textView,textView30,textView31;
    Button button30,button31;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        textView = findViewById(R.id.textView);
        textView30 = findViewById(R.id.textView30);
        textView31 = findViewById(R.id.textView31);

        Intent intent6 = getIntent();
        Integer score_41 = intent6.getIntExtra("score5",0);
        Integer progress_41 = intent6.getIntExtra("progress5",0);
        String name = intent6.getStringExtra("username");
        textView.setText("Congratulations" +name);
        textView31.setText(score_41 + "/5");

    }
    public void finish(View view)
    {
        finish();
        moveTaskToBack(true);
    }

    public void newButton(View view)
    {
        Intent intent = getIntent();
        Intent intent31 = new Intent(this, MainActivity.class);
        intent31.putExtra("username", intent.getStringExtra("username"));
        startActivity(intent31);
    }
}