package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity3 extends AppCompatActivity {

    TextView textView9,textView10,textView11;

    ProgressBar progressBar;
    String choice;
    Button button11, button12, button13, button14,button15;
    int score2,progress2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        textView9 = findViewById((R.id.textView9));
        textView10 = findViewById((R.id.textView10));
        textView11 = findViewById((R.id.textView11));
        button11 = findViewById(R.id.button11);
        button12 = findViewById(R.id.button12);
        button13 = findViewById(R.id.button13);
        button14 = findViewById(R.id.button14);
        button15 = findViewById(R.id.button15);
        progressBar =findViewById(R.id.progressBar);


        Intent intent2 = getIntent();
        String name = intent2.getStringExtra("username");
        Integer score_2 = intent2.getIntExtra("score1",0);
        Integer progress_2 = intent2.getIntExtra("progress1",0);
        progressBar.setProgress(progress_2);
        textView9.setText("Welcome " + name + "!");
        score2 = score_2;
        progress2 = progress_2;

        button11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                choice = "first";
            }
        });

        button12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                choice = "second";
            }
        });

        button13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                choice = "third";
            }
        });

        button14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (choice == "first")
                {
                    button12.setBackgroundColor(Color.GREEN);
                    button11.setBackgroundColor(Color.RED);
                    button14.setVisibility(View.INVISIBLE);
                    button14.setEnabled(false);
                    button15.setVisibility(View.VISIBLE);
                    button15.setEnabled(true);
                    progress2++;

                }

                else if (choice == "second")
                {
                    button12.setBackgroundColor(Color.GREEN);
                    button14.setVisibility(View.INVISIBLE);
                    button14.setEnabled(false);
                    button15.setVisibility(View.VISIBLE);
                    button15.setEnabled(true);
                    score2++;
                    progress2++;
                }

                else if (choice == "third")
                {
                    button12.setBackgroundColor(Color.GREEN);
                    button13.setBackgroundColor(Color.RED);
                    button14.setVisibility(View.INVISIBLE);
                    button14.setEnabled(false);
                    button15.setVisibility(View.VISIBLE);
                    button15.setEnabled(true);
                    progress2++;
                }

                else
                {
                    Toast.makeText(MainActivity3.this, "Select an option", Toast.LENGTH_LONG).show();
                }
            }
        });

    }

    public void Next1(View view)
    {
        Intent intent = getIntent();
        Intent intent3 = new Intent(this, MainActivity5.class);
        intent3.putExtra("username",intent.getStringExtra("username"));
        intent3.putExtra("score2",score2);
        intent3.putExtra("progress2",progress2);
        startActivity(intent3);
    }
}