package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.graphics.Color;
import android.content.Intent;
import android.view.View;
import android.widget.Toast;
import android.widget.TextView;

import android.os.Bundle;

public class MainActivity2 extends AppCompatActivity {

    TextView textView6,textView7,textView8;
    int score;
    int progress = 1;
    ProgressBar progressBar;
    String Response;
    Button button6, button7, button8, button9,button10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        textView6 = findViewById((R.id.textView6));
        textView7 = findViewById((R.id.textView7));
        textView8 = findViewById((R.id.textView8));
        button6 = findViewById(R.id.button6);
        button7 = findViewById(R.id.button7);
        button8 = findViewById(R.id.button8);
        button9 = findViewById(R.id.button9);
        button10 = findViewById(R.id.button10);
        progressBar =findViewById(R.id.progressBar);

        Intent intent = getIntent();
        String name = intent.getStringExtra("username");
        textView6.setText("Welcome " + name + "!");

        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Response = "first";
            }
        });

        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Response = "second";
            }
        });

        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Response = "third";
            }
        });

        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               if (Response == "first")
               {
                    button7.setBackgroundColor(Color.GREEN);
                    button6.setBackgroundColor(Color.RED);
                    button9.setVisibility(View.INVISIBLE);
                    button9.setEnabled(false);
                   button10.setVisibility(View.VISIBLE);
                   button10.setEnabled(true);
                   progress++;
               }

                else if (Response == "second")
                {
                    button7.setBackgroundColor(Color.GREEN);
                    button9.setVisibility(View.INVISIBLE);
                    button9.setEnabled(false);
                    button10.setVisibility(View.VISIBLE);
                    button10.setEnabled(true);
                    score=1;
                    progress++;
                }

                else if (Response == "third")
                {
                    button7.setBackgroundColor(Color.GREEN);
                    button8.setBackgroundColor(Color.RED);
                    button9.setVisibility(View.INVISIBLE);
                    button9.setEnabled(false);
                    button10.setVisibility(View.VISIBLE);
                    button10.setEnabled(true);
                    progress++;
                }

                else
               {
                   Toast.makeText(MainActivity2.this, "Select an option", Toast.LENGTH_LONG).show();
               }
            }
        });

    }

    public void Next(View view)
    {
        Intent intent = getIntent();
        Intent intent2 = new Intent(this, MainActivity3.class);
        intent2.putExtra("username",intent.getStringExtra("username"));
        intent2.putExtra("score1",score);
        intent2.putExtra("progress1",progress);
        startActivity(intent2);
    }
}