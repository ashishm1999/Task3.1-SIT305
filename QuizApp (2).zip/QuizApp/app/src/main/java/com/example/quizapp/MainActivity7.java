package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity7 extends AppCompatActivity {

    TextView textView18,textView19,textView20;

    ProgressBar progressBar;
    String choice;
    Button button26, button27, button28, button29,button30;
    int score5,progress5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main7);

        textView18 = findViewById((R.id.textView18));
        textView19 = findViewById((R.id.textView19));
        textView20 = findViewById((R.id.textView20));
        button26 = findViewById(R.id.button26);
        button27 = findViewById(R.id.button27);
        button28 = findViewById(R.id.button28);
        button29 = findViewById(R.id.button29);
        button30 = findViewById(R.id.button30);
        progressBar =findViewById(R.id.progressBar);


        Intent intent5 = getIntent();
        String name = intent5.getStringExtra("username");
        Integer score_5 = intent5.getIntExtra("score4",0);
        Integer progress_5 = intent5.getIntExtra("progress4",0);
        progressBar.setProgress(progress_5);
        textView18.setText("Welcome " + name + "!");
        score5 = score_5;
        progress5 = progress_5;

        button26.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                choice = "first";
            }
        });

        button27.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                choice = "second";
            }
        });

        button28.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                choice = "third";
            }
        });

        button29.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (choice == "first")
                {
                    button27.setBackgroundColor(Color.GREEN);
                    button26.setBackgroundColor(Color.RED);
                    button29.setVisibility(View.INVISIBLE);
                    button29.setEnabled(false);
                    button30.setVisibility(View.VISIBLE);
                    button30.setEnabled(true);
                    progress5++;

                }

                else if (choice == "second")
                {
                    button27.setBackgroundColor(Color.GREEN);
                    button29.setVisibility(View.INVISIBLE);
                    button29.setEnabled(false);
                    button30.setVisibility(View.VISIBLE);
                    button30.setEnabled(true);
                    score5++;
                    progress5++;
                }

                else if (choice == "third")
                {
                    button27.setBackgroundColor(Color.GREEN);
                    button28.setBackgroundColor(Color.RED);
                    button29.setVisibility(View.INVISIBLE);
                    button29.setEnabled(false);
                    button30.setVisibility(View.VISIBLE);
                    button30.setEnabled(true);
                    progress5++;
                }

                else
                {
                    Toast.makeText(MainActivity7.this, "Select an option", Toast.LENGTH_LONG).show();
                }
            }
        });

    }

    public void Next4(View view)
    {
        Intent intent = getIntent();
        Intent intent6 = new Intent(this, MainActivity4.class);
        intent6.putExtra("username",intent.getStringExtra("username"));
        intent6.putExtra("score5",score5);
        intent6.putExtra("progress5",progress5);
        startActivity(intent6);
    }
}