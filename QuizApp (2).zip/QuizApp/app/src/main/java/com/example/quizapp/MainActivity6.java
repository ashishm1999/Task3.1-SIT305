package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity6 extends AppCompatActivity {

    TextView textView15,textView16,textView17;

    ProgressBar progressBar;
    String choice;
    Button button21, button22, button23, button24,button25;
    int score4,progress4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);

        textView15 = findViewById((R.id.textView15));
        textView16 = findViewById((R.id.textView16));
        textView17 = findViewById((R.id.textView17));
        button21 = findViewById(R.id.button21);
        button22 = findViewById(R.id.button22);
        button23 = findViewById(R.id.button23);
        button24 = findViewById(R.id.button24);
        button25 = findViewById(R.id.button25);
        progressBar =findViewById(R.id.progressBar);


        Intent intent4 = getIntent();
        String name = intent4.getStringExtra("username");
        Integer score_4 = intent4.getIntExtra("score3",0);
        Integer progress_4 = intent4.getIntExtra("progress3",0);
        progressBar.setProgress(progress_4);
        textView15.setText("Welcome " + name + "!");
        score4 = score_4;
        progress4 = progress_4;

        button21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                choice = "first";
            }
        });

        button22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                choice = "second";
            }
        });

        button23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                choice = "third";
            }
        });

        button24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (choice == "first")
                {
                    button22.setBackgroundColor(Color.GREEN);
                    button21.setBackgroundColor(Color.RED);
                    button24.setVisibility(View.INVISIBLE);
                    button24.setEnabled(false);
                    button25.setVisibility(View.VISIBLE);
                    button25.setEnabled(true);
                    progress4++;

                }

                else if (choice == "second")
                {
                    button22.setBackgroundColor(Color.GREEN);
                    button24.setVisibility(View.INVISIBLE);
                    button24.setEnabled(false);
                    button25.setVisibility(View.VISIBLE);
                    button25.setEnabled(true);
                    score4++;
                    progress4++;
                }

                else if (choice == "third")
                {
                    button22.setBackgroundColor(Color.GREEN);
                    button23.setBackgroundColor(Color.RED);
                    button24.setVisibility(View.INVISIBLE);
                    button24.setEnabled(false);
                    button25.setVisibility(View.VISIBLE);
                    button25.setEnabled(true);
                    progress4++;
                }

                else
                {
                    Toast.makeText(MainActivity6.this, "Select an option", Toast.LENGTH_LONG).show();
                }
            }
        });

    }

    public void Next3(View view)
    {
        Intent intent = getIntent();
        Intent intent5 = new Intent(this, MainActivity7.class);
        intent5.putExtra("username",intent.getStringExtra("username"));
        intent5.putExtra("score4",score4);
        intent5.putExtra("progress4",progress4);
        startActivity(intent5);
    }
}