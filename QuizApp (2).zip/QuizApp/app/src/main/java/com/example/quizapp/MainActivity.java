package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.graphics.Color;
import android.content.Intent;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    Button START;
    TextView textView1,textView2;
    EditText edit1;

    public void START(View view)
    {
        Intent intent = new Intent(this, MainActivity2.class);
        intent.putExtra("username",edit1.getText().toString());
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        START = findViewById(R.id.button1);
        textView1 = findViewById((R.id.textView1));
        textView2 = findViewById((R.id.textview2));
        edit1 = findViewById(R.id.edit1);

        if (edit1 != null)
        {
            Intent intent = getIntent();
            String names = intent.getStringExtra("username");
            edit1.setText(names);
        }

    }
}