package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity5 extends AppCompatActivity {

    TextView textView12,textView13,textView14;

    ProgressBar progressBar;
    String choice;
    Button button16, button17, button18, button19,button20;
    int score3,progress3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        textView12 = findViewById((R.id.textView12));
        textView13 = findViewById((R.id.textView13));
        textView14 = findViewById((R.id.textView14));
        button16 = findViewById(R.id.button16);
        button17 = findViewById(R.id.button17);
        button18 = findViewById(R.id.button18);
        button19 = findViewById(R.id.button19);
        button20 = findViewById(R.id.button20);
        progressBar =findViewById(R.id.progressBar);


        Intent intent3 = getIntent();
        String name = intent3.getStringExtra("username");
        Integer score_3 = intent3.getIntExtra("score2",0);
        Integer progress_3 = intent3.getIntExtra("progress2",0);
        progressBar.setProgress(progress_3);
        textView12.setText("Welcome " + name + "!");
        score3 = score_3;
        progress3 = progress_3;

        button16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                choice = "first";
            }
        });

        button17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                choice = "second";
            }
        });

        button18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                choice = "third";
            }
        });

        button19.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (choice == "first")
                {
                    button17.setBackgroundColor(Color.GREEN);
                    button16.setBackgroundColor(Color.RED);
                    button19.setVisibility(View.INVISIBLE);
                    button19.setEnabled(false);
                    button20.setVisibility(View.VISIBLE);
                    button20.setEnabled(true);
                    progress3++;

                }

                else if (choice == "second")
                {
                    button17.setBackgroundColor(Color.GREEN);
                    button19.setVisibility(View.INVISIBLE);
                    button19.setEnabled(false);
                    button20.setVisibility(View.VISIBLE);
                    button20.setEnabled(true);
                    score3++;
                    progress3++;
                }

                else if (choice == "third")
                {
                    button17.setBackgroundColor(Color.GREEN);
                    button18.setBackgroundColor(Color.RED);
                    button19.setVisibility(View.INVISIBLE);
                    button19.setEnabled(false);
                    button20.setVisibility(View.VISIBLE);
                    button20.setEnabled(true);
                    progress3++;
                }

                else
                {
                    Toast.makeText(MainActivity5.this, "Select an option", Toast.LENGTH_LONG).show();
                }
            }
        });

    }

    public void Next2(View view)
    {
        Intent intent = getIntent();
        Intent intent4 = new Intent(this, MainActivity6.class);
        intent4.putExtra("username",intent.getStringExtra("username"));
        intent4.putExtra("score3",score3);
        intent4.putExtra("progress3",progress3);
        startActivity(intent4);
    }
}